package com.registration.registration.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.registration.registration.model.User;
import com.registration.registration.service.RegistrationService;

@RestController

public class ResgistrationController {
	
	@Autowired
	private RegistrationService serv;
	
	
	@PostMapping("/registeruser")
	@CrossOrigin(origins = "http://localhost:4200")
	public User registerUser( @RequestBody User user) throws Exception
	{
		String tempEmailid = user.getEmailId();
		if(tempEmailid != null && !"".equals(tempEmailid))
		{
			User user1 = serv.fetchUserByEmailId(tempEmailid);
			
			if(user1 != null)
			{
				throw new Exception("User with " +tempEmailid+ " is already exist");
			}
		}
		
		User userobj; //User userobj = null;
		userobj = serv.saveUser(user);
		return userobj;
	}
	
	@PostMapping("/login")
	@CrossOrigin(origins = "http://localhost:4200")
	public User loginUser(@RequestBody User user) throws Exception
	{
		String tempEmailId = user.getEmailId();
		String tempPass = user.getPassword();
		User userobj = null;
		
		if(tempEmailId != null && tempPass != null)
		{
		 userobj = serv.fetchUserByEmailIdAndPassword(tempEmailId, tempPass);
			
		}
		if(userobj == null)
		{
			throw new Exception("User does not exist");
		}
		
		return userobj;
	}

}
